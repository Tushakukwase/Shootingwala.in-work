"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Facebook, Instagram, Twitter, Youtube, Apple, Play } from "lucide-react"
import { useState } from "react"

export default function HomePage() {
  const [categoriesScroll, setCategoriesScroll] = useState(0)
  const [citiesScroll, setCitiesScroll] = useState(0)

  const categories = [
    { name: "Wedding", image: "/placeholder.svg?height=200&width=200" },
    { name: "Prewedding", image: "/placeholder.svg?height=200&width=200" },
    { name: "Baby Shoot", image: "/placeholder.svg?height=200&width=200" },
    { name: "Model Shoot", image: "/placeholder.svg?height=200&width=200" },
    { name: "Makeup Shoot", image: "/placeholder.svg?height=200&width=200" },
  ]

  const cities = [
    { name: "Mumbai", image: "/placeholder.svg?height=200&width=200" },
    { name: "Pune", image: "/placeholder.svg?height=200&width=200" },
    { name: "Nagpur", image: "/placeholder.svg?height=200&width=200" },
    { name: "New Delhi", image: "/placeholder.svg?height=200&width=200" },
    { name: "Bangalore", image: "/placeholder.svg?height=200&width=200" },
  ]

  const weddingStories = [
    {
      title: "Vinay and Sahil",
      subtitle: "Patiala, Mohali, Pre-Wedding Shoot & A Bride Who Slayed in Chandigarh",
      date: "February 2019",
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      title: "Tanushree and Uday",
      subtitle: "This Glamorous Sikh Couple Wedding in West Marredpally, Hyderabad",
      date: "February 2019",
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      title: "Divya and Rohini",
      subtitle: "A Cross-Cultural Hyderabadi Wedding That Redefined Grand Celebrations",
      date: "January 2019",
      image: "/placeholder.svg?height=300&width=400",
    },
  ]

  const galleryItems = [
    { name: "Bridal Lehenga", image: "/placeholder.svg?height=200&width=200" },
    { name: "Outfits", image: "/placeholder.svg?height=200&width=200" },
    { name: "Blouse Designs", image: "/placeholder.svg?height=200&width=200" },
    { name: "Wedding Sarees", image: "/placeholder.svg?height=200&width=200" },
    { name: "Mehndi Designs", image: "/placeholder.svg?height=200&width=200" },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="bg-gray-900 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/" className="text-2xl font-bold text-white">
                ShootingWala
              </Link>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <Link href="/categories" className="text-white hover:text-orange-400 transition-colors">
                Categories
              </Link>
              <Link href="/photos" className="text-white hover:text-orange-400 transition-colors">
                Photos
              </Link>
              <Link href="/download" className="text-white hover:text-orange-400 transition-colors">
                Download App
              </Link>
            </div>
            <Button
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-gray-900 bg-transparent"
            >
              Log In
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center">
        <div className="absolute inset-0">
          <Image
            src="/placeholder.svg?height=600&width=1200"
            alt="Wedding couple"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-black bg-opacity-50" />
        </div>
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">Make Your Moment Very Special</h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200">Find Best Photographers With Trusted Values</p>
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <Button
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-gray-900 bg-transparent"
            >
              Search By Category
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-gray-900 bg-transparent"
            >
              Search By City
            </Button>
            <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-white">
              Get Started
            </Button>
          </div>
        </div>
      </section>

      {/* Popular Searches Categories */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-900">Popular Searches Categories</h2>
          <div className="relative">
            <div className="flex overflow-x-auto space-x-6 pb-4 scrollbar-hide">
              {categories.map((category, index) => (
                <Card key={index} className="flex-shrink-0 w-64 shadow-lg hover:shadow-xl transition-shadow">
                  <CardContent className="p-0">
                    <div className="relative h-48">
                      <Image
                        src={category.image || "/placeholder.svg"}
                        alt={category.name}
                        fill
                        className="object-cover rounded-t-lg"
                      />
                    </div>
                    <div className="p-4">
                      <h3 className="text-lg font-semibold text-center text-gray-900">{category.name}</h3>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Popular Searches Cities */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-900">Popular Searches Cities</h2>
          <div className="relative">
            <div className="flex overflow-x-auto space-x-6 pb-4 scrollbar-hide">
              {cities.map((city, index) => (
                <Card key={index} className="flex-shrink-0 w-64 shadow-lg hover:shadow-xl transition-shadow">
                  <CardContent className="p-0">
                    <div className="relative h-48">
                      <Image
                        src={city.image || "/placeholder.svg"}
                        alt={city.name}
                        fill
                        className="object-cover rounded-t-lg"
                      />
                    </div>
                    <div className="p-4">
                      <h3 className="text-lg font-semibold text-center text-gray-900">{city.name}</h3>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Other Services */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-900">ShootingWala Other Services</h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-0">
                <div className="relative h-64">
                  <Image
                    src="/placeholder.svg?height=300&width=400"
                    alt="Digital Album"
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <div className="p-6 text-center">
                  <h3 className="text-xl font-bold mb-4 text-gray-900">Digital Album</h3>
                  <Button
                    variant="outline"
                    className="border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white bg-transparent"
                  >
                    Know More
                  </Button>
                </div>
              </CardContent>
            </Card>
            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-0">
                <div className="relative h-64">
                  <Image
                    src="/placeholder.svg?height=300&width=400"
                    alt="Digital Invitation"
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <div className="p-6 text-center">
                  <h3 className="text-xl font-bold mb-4 text-gray-900">Digital Invitation</h3>
                  <Button
                    variant="outline"
                    className="border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white bg-transparent"
                  >
                    Know More
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Real Wedding Stories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-12 text-gray-900">Real Wedding Stories</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {weddingStories.map((story, index) => (
              <Card key={index} className="shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-0">
                  <div className="relative h-48">
                    <Image
                      src={story.image || "/placeholder.svg"}
                      alt={story.title}
                      fill
                      className="object-cover rounded-t-lg"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="font-bold text-lg mb-2 text-gray-900">{story.title}</h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">{story.subtitle}</p>
                    <p className="text-gray-500 text-xs">{story.date}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery to Look for */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-900">Gallery to Look for</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
            {galleryItems.map((item, index) => (
              <Card key={index} className="shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
                <CardContent className="p-0">
                  <div className="relative h-32">
                    <Image
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      fill
                      className="object-cover rounded-t-lg"
                    />
                  </div>
                  <div className="p-3">
                    <h3 className="font-semibold text-sm text-center text-gray-900">{item.name}</h3>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Left Side - Contact Details */}
            <div>
              <h3 className="text-xl font-bold mb-4">ShootingWala</h3>
              <p className="text-gray-300 mb-4">Your Favorite Photographer Finder</p>
              <div className="space-y-2 text-sm text-gray-300">
                <p className="font-semibold">Contact us to get best deals</p>
                <div className="space-y-1">
                  <p>
                    <span className="font-semibold">For Photographer:</span>
                  </p>
                  <p>📧 info@shootingwala.in</p>
                  <p>📞 7798766666</p>
                </div>
                <div className="space-y-1">
                  <p>
                    <span className="font-semibold">For User:</span>
                  </p>
                  <p>📧 info@shootingwala.in</p>
                  <p>📞 7798766666</p>
                </div>
                <div className="mt-4">
                  <p className="font-semibold">Registered Address:</p>
                  <p>Hanuman Ward, Tujpur, Bhandara</p>
                  <p>Maharashtra - 441904</p>
                </div>
              </div>
            </div>

            {/* Center - Social Media */}
            <div className="text-center">
              <h4 className="text-lg font-semibold mb-4">Follow us on:</h4>
              <div className="flex justify-center space-x-4 mb-6">
                <Link href="#" className="text-gray-300 hover:text-white transition-colors">
                  <Facebook className="w-6 h-6" />
                </Link>
                <Link href="#" className="text-gray-300 hover:text-white transition-colors">
                  <Instagram className="w-6 h-6" />
                </Link>
                <Link href="#" className="text-gray-300 hover:text-white transition-colors">
                  <Twitter className="w-6 h-6" />
                </Link>
                <Link href="#" className="text-gray-300 hover:text-white transition-colors">
                  <Youtube className="w-6 h-6" />
                </Link>
              </div>
            </div>

            {/* Right Side - App Downloads */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Get The ShootingWala App</h4>
              <div className="space-y-3">
                <Link
                  href="#"
                  className="flex items-center space-x-3 bg-black rounded-lg px-4 py-3 hover:bg-gray-800 transition-colors"
                >
                  <Apple className="w-8 h-8" />
                  <div>
                    <p className="text-xs text-gray-300">Download on the</p>
                    <p className="text-sm font-semibold">App Store</p>
                  </div>
                </Link>
                <Link
                  href="#"
                  className="flex items-center space-x-3 bg-black rounded-lg px-4 py-3 hover:bg-gray-800 transition-colors"
                >
                  <Play className="w-8 h-8" />
                  <div>
                    <p className="text-xs text-gray-300">GET IT ON</p>
                    <p className="text-sm font-semibold">Google Play</p>
                  </div>
                </Link>
              </div>
            </div>
          </div>

          {/* Bottom Footer */}
          <div className="border-t border-gray-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-300">©2025 ShootingWala</p>
            <p className="text-sm text-gray-300">Design By: Swashtech</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
